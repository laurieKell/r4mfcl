##' Saves R graphic as a jpeg file.
##' Requires Imagemagick program "convert".
##' @title jpegfile
##' @param fname Output file name root (or path)
##' @return No return value
##' @author Pierre Kleiber
jpegfile <-
  function (fname = "R-plot") 
{
  fname <- gsub("\\.jpg$", "", fname)
  dev.copy2pdf(file = paste(fname, ".pdf", sep = ""))
  system(paste("convert -quiet ", " ", fname, ".pdf ", 
               fname, ".jpg", sep = ""))
  file.remove(paste(fname, ".pdf", sep = ""))
  invisible()
}
