myfunction <- function(n) {
  options(width=n)

}
