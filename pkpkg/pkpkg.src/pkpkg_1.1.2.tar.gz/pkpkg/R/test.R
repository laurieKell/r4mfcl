test <- function(a){
  2*a
}

